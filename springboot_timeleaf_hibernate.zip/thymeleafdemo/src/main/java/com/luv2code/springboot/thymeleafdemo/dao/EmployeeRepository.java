package com.luv2code.springboot.thymeleafdemo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.luv2code.springboot.thymeleafdemo.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
											//here <entitytype,primarykey> 
		//we can just plugin our own entities like for manager,student etc.., along with it's primary key
	// that's it ... no need to write any code LOL!
	//here we are adding a method to sort by last name 
	public List<Employee> findAllByOrderByLastNameAsc();
	//Spring data jpa will parse the method name and look for the specific format and pattern
		//and creates the appropriate query(orderby,...) behind the scenes 
			//this is spring data jpa magic
	//luv2code.com/query-methods
	
}
